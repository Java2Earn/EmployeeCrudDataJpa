package com.serialization;

import java.io.Serializable;

public class Emp implements Serializable
{
int id;
String name;
int atmpin;
public Emp(int id, String name, int atmpin) {
	super();
	this.id = id;
	this.name = name;
	this.atmpin = atmpin;
}

}
