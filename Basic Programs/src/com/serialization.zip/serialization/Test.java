package com.serialization;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
public class Test 
{
public static void main(String[] args) throws IOException {
	Emp e=new Emp(12345,"sandeep",1256);
	
	FileOutputStream fos=new FileOutputStream("welcome.txt");
	ObjectOutputStream oos=new ObjectOutputStream(fos);
	oos.writeObject(e);
	System.out.println("done");
}
}
